﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Piatnica.Dal.Models
{
    public class Event
    {
        public int Id { get; set; }
        public string Name { get; set; }

        ICollection<Event_History> Event_Histories { get; set; }
        ICollection<Distance_History> Distance_Histories { get; set; }
        
    }
}