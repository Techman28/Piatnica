﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace Piatnica.Dal.Models
{
    public class Delay
    {
        public int Id { get; set; }
        public int Delay_Order { get; set; }
        public DateTime Date { get; set; }
    }
}