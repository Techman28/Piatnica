﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Piatnica.Dal.Models
{
   public class Location_History
    {
        public int Id { get; set; }
        public double Longitude { get; set; }
        public double LatitudeL { get; set; }
        public DateTime date { get; set; }



    }
}