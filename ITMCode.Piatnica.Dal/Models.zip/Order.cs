﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Piatnica.Dal.Models
{
    public class Order
    {
        public Order() { }
        public int Id { get; set; }
    
        public virtual Order_State Order_state { get; set; }
        public ICollection<Location_History> Location_Histories { get; set; }
        public ICollection<Distance_History> Distance_Histories { get; set; }
        public ICollection<Order_Entry> Order_Entries { get; set; }

    }
}