﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Piatnica.Dal.Models
{
    public class Order_Entry
    {
        public int Id { get; set; }
        public string Order_Type { get; set; }
        public string Location { get; set; }
        public DateTime date { get; set; }
        public DateTime From_Time { get; set; }
        public DateTime To_Time { get; set; }
        public string Cargo { get; set; }
        public string Comments { get; set; }
        public int Status { get; set; }


        ICollection<Order_Entry> Order_Entries { get; set; }

    }
}