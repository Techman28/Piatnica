﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Piatnica.Dal.Models
{
    public class Distance_History
    {
        public int Id { get; set; }
        public double Distance { get; set; }
        public DateTime date { get; set; }


    }
}